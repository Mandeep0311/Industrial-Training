import { Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CustomerComponent } from './customer/customer.component';
import { LoginComponent } from './admin/login/login.component';
import { AdminArtPiecesComponent } from './admin/art-pieces/art-pieces.component';
import { AdminBookingComponent } from './admin/booking/booking.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { ManageCustomerComponent } from './admin/manage-customer/manage-customer.component';
import { PostComponent } from './admin/post/post.component';

import { ArtPieceComponent } from './customer/art-piece/art-piece.component';
import { BookingsComponent } from './customer/bookings/bookings.component';
import { DesignComponent } from './customer/design/design.component';
import { AdminDesignComponent } from './admin/design/design.component';
import { LayoutComponent } from './customer/layout/layout.component';
import { RegisterComponent } from './customer/register/register.component';

export const routes: Routes = [

    { 
        path:'', redirectTo:'/dashboard', pathMatch:"full"
    },
    {
        path:'admin', component:AdminComponent
    },
    {
        path:'login',component:LoginComponent
    },
    {
        path:'art-piece', component:AdminArtPiecesComponent
    },
    {
        path:'booking', component:AdminBookingComponent
    },
    {
        path:'dashboard', component:DashboardComponent
    },
    {
        path:'manage-customer', component:ManageCustomerComponent
    },
    {
        path:'post', component:PostComponent
    },
    {
        path:'design', component:AdminDesignComponent
    },

    {
        path:'customer', component:CustomerComponent
    },
    {   
        path:'art-piece', component:ArtPieceComponent
    },
    {   
        path:'bookings', component:BookingsComponent
    },
    {   
        path:'design', component:DesignComponent
    }, 
    {   
        path:'layout', component:LayoutComponent
    },
    {   
        path:'login', component:LoginComponent
    },
    {
        path:'register', component:RegisterComponent
    },

];
