import { Booking } from './booking.model';

describe('Booking', () => {
  it('should create an instance', () => {
    expect(new Booking()).toBeTruthy();
  });
});
