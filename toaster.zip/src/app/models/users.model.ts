export class Users {
    id?: String;
    name?: String;
    email?: String;
    password?:String;
    contact?: String;
    address?: String;
    uid?: String;
    createdAt?: String;
    status?: String;
}
