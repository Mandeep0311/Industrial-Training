import { Component } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { UserService } from '../../shared/user.service';
import { Router } from '@angular/router';
import { DocumentData } from 'firebase/firestore';
import { Users } from '../../models/users.model';


@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  title : 'login' = 'login'
  users: DocumentData[] = [];
  constructor(private router: Router, private userService: UserService){ }

  userObj: Users={}   
  async login()
  {
    this.userService.login(this.userObj.email, this.userObj.password);
  }
}
