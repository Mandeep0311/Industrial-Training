import {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
} from "./chunk-G4WGTC4V.js";
import "./chunk-OAUL23LK.js";
import "./chunk-R7SVVUUO.js";
import "./chunk-V5MEANWS.js";
import "./chunk-X7LI2NJC.js";
import "./chunk-5D7M7OFP.js";
import "./chunk-A4RDU57L.js";
import "./chunk-VLJ5ROQC.js";
import "./chunk-DA4C6Y77.js";
import "./chunk-HRVVZ7O7.js";
import "./chunk-BIZ6S7EG.js";
import "./chunk-OPJDHPG3.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-35ENWJA4.js";
export {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
};
