import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-R7SVVUUO.js";
import "./chunk-V5MEANWS.js";
import "./chunk-VLJ5ROQC.js";
import "./chunk-DA4C6Y77.js";
import "./chunk-BIZ6S7EG.js";
import "./chunk-OPJDHPG3.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-35ENWJA4.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
