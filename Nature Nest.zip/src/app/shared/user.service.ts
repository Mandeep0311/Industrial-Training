import { Injectable } from '@angular/core';
import { Firestore, collection, addDoc, getDocs, query, where } from '@angular/fire/firestore';
import { Users } from '../models/users.model'; 

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private firestore: Firestore) { }

  setData(res: { token: string }) {
    sessionStorage.setItem('token', res.token);
  }
  
  getToken() {
    return sessionStorage.getItem('token');
  }

  async addUser(collectionName: string, data: any) {
    const userCollection = collection(this.firestore, collectionName);
    return await addDoc(userCollection, data);
  }

  async getUser(collectionName: string, email: string): Promise<Users | null> {
    const userCollection = collection(this.firestore, collectionName);
    const q = query(userCollection, where('email', '==', email));
    const querySnapshot = await getDocs(q);

  if (querySnapshot.empty) {
    return null;
  } else {
    const userDoc = querySnapshot.docs[0];
    return {
        id: userDoc.id,
        ...userDoc.data()
      } as Users;
    }
  }
  
  async loginUser(collectionName: string, data: any) {
    const loginCollection = collection(this.firestore, collectionName);
    return await addDoc(loginCollection, data);
  }

  clear() {
    sessionStorage.clear();
  }
}


