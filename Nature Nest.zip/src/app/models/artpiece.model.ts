export class Artpiece {
    id?: String;
    name?: String;
    description?: String;
    image?: String;
    createdAt?: String;
    status?: String;
}

