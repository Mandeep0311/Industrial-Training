import { Component } from '@angular/core';

@Component({
  selector: 'app-art-piece',
  imports: [],
  templateUrl: './art-piece.component.html',
  styleUrl: './art-piece.component.css'
})
export class ArtPieceComponent {

}
