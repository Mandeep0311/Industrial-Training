import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../shared/auth.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
title: 'register' = 'register'


  registerForm = new FormGroup({
    fullName: new FormControl('',Validators.required),
    email: new FormControl( '',[Validators.required, Validators.email]),
    password: new FormControl('',Validators.required),
    phone: new FormControl('',Validators.required),
    terms: new FormControl('',Validators.required)
    
  })

  constructor(private router:Router, private authService: AuthService){}

  onSubmit(){
    alert(this.registerForm.value.fullName)
    if (
      this.registerForm.value.email == 'student@gmail.com' &&
      this.registerForm.value.password == '123'
    ) {
      this.authService.setData(this.registerForm.value)
      this.router.navigateByUrl('/login');
    } else {
      alert('Invalid email or password');
    }
  }
}

