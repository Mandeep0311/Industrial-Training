export const environment = {

    production:false,
    firebase: {
        apiKey: "AIzaSyC1OyDIH6Se_n52jCQ4tf9pLUTr2z2QXGM",
  authDomain: "natures-nest-f5ea9.firebaseapp.com",
  projectId: "natures-nest-f5ea9",
  storageBucket: "natures-nest-f5ea9.firebasestorage.app",
  messagingSenderId: "112444964952",
  appId: "1:112444964952:web:96059f869a41701906ca2d",
  measurementId: "G-V2RE8E2XF4"
    }


};
