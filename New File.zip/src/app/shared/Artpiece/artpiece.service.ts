import { Injectable } from '@angular/core';
import { DocumentData } from '@angular/fire/compat/firestore';
import { addDoc, collection, CollectionReference, updateDoc, where } from 'firebase/firestore';
import { Artpiece } from '../../model/Artpiece/artpiece.model';
import { Observable } from 'rxjs';
import { collectionData, docData, Firestore, doc, deleteDoc, query } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class ArtpieceService {

  private dbpath = '/Artpiece';
  private ArtpieceRef: CollectionReference<DocumentData>;


  constructor(private db: Firestore) {
    this.ArtpieceRef = collection(this.db, this.dbpath);
   }
   add(ArtpieceObj: Artpiece) {
    ArtpieceObj.createdAt=Date.now();
    ArtpieceObj.status = true;
    return addDoc(this.ArtpieceRef, {...ArtpieceObj });
   }
   getAll(): Observable<Artpiece>{
    return collectionData(query(this.ArtpieceRef,where('status', '==', true)), 
    { idField:'id' }) as Observable<Artpiece>;
   }

   deleteData(id:string){
    return deleteDoc(doc(this.ArtpieceRef, id));
   }
   getSingle(id: string)
   {
    return docData(doc(this.ArtpieceRef,id), {idField:'id'});
   }
   updateData(id: string, data: Partial<Artpiece>)
   {
    return updateDoc(doc(this.ArtpieceRef,id),data);
   }
}
