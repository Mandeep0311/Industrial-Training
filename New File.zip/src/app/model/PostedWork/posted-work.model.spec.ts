import { PostedWork } from './posted-work.model';

describe('PostedWork', () => {
  it('should create an instance', () => {
    expect(new PostedWork()).toBeTruthy();
  });
});
