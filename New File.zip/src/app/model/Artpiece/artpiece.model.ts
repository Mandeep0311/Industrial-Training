export class Artpiece {

    id?: string;
    name?: string;
    discription?: string;
    image?: string;
    status?: boolean;
    createdAt?: number;
}
