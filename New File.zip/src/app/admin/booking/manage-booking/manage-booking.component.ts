import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-booking',
  imports: [],
  templateUrl: './manage-booking.component.html',
  styleUrl: './manage-booking.component.css'
})
export class ManageBookingComponent {

}
