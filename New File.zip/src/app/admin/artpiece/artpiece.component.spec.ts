import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtpieceComponent } from './artpiece.component';

describe('ArtpieceComponent', () => {
  let component: ArtpieceComponent;
  let fixture: ComponentFixture<ArtpieceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ArtpieceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ArtpieceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
