import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Artpiece } from '../../../model/Artpiece/artpiece.model';
import { ArtpieceService } from '../../../shared/Artpiece/artpiece.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-add-artpiece',
  imports: [FormsModule],
  templateUrl: './add-artpiece.component.html',
  styleUrl: './add-artpiece.component.css'
})
export class AddArtpieceComponent {

  ArtpieceObj: Artpiece={}

  constructor(
     private ArtpieceService: ArtpieceService,
     private router: Router,
     private Toastr: ToastrService,
     private spinner: NgxSpinnerService,
     private cloudinaryService: CloudinaryService

  ){}

}
