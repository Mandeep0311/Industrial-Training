import { Artpiece } from './artpiece.model';

describe('Artpiece', () => {
  it('should create an instance', () => {
    expect(new Artpiece()).toBeTruthy();
  });
});
