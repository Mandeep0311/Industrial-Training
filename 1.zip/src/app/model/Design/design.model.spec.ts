import { Design } from './design.model';

describe('Design', () => {
  it('should create an instance', () => {
    expect(new Design()).toBeTruthy();
  });
});
