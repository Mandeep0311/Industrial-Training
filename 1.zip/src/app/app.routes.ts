import { Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { LayoutComponent } from './admin/layout/layout.component';
import { PostComponent } from './admin/post/post.component';
import { ArtpieceComponent } from './admin/artpiece/artpiece.component';
import { BookingComponent } from './admin/booking/booking.component';
import { ManageCustomerComponent } from './admin/manage-customer/manage-customer.component';
import { LoginComponent } from './admin/login/login.component';
import { RegisterComponent } from './customer/register/register.component';
import { DesignComponent } from './admin/design/design.component';
import { AddArtpieceComponent } from './admin/artpiece/add-artpiece/add-artpiece.component';
import { ManageArtpieceComponent } from './admin/artpiece/manage-artpiece/manage-artpiece.component';
import { UpdateArtpieceComponent } from './admin/artpiece/update-artpiece/update-artpiece.component';
import { AddBookingComponent } from './admin/booking/add-booking/add-booking.component';

import { UpdateBookingComponent } from './admin/booking/update-booking/update-booking.component';

export const routes: Routes = [
    {
        path: '', redirectTo: '/admin/dashboard', pathMatch: 'full'
    },
    {
        path: 'admin', component: LayoutComponent, children: [
            {
                path: 'dashboard', component: DashboardComponent
            },
            {
                path: 'admin', component: AdminComponent
            },
            {
                path: 'post', component: PostComponent
            },
            {
                path: 'Artpiece', component: ArtpieceComponent
            },
            {
                path: 'Artpiece/AddArtpiece', component: AddArtpieceComponent
            },
            {
                path: 'Artpiece/Manage', component: ManageArtpieceComponent
            },
            {
                path : 'Artpiece/update', component: UpdateArtpieceComponent
            },
            {
                path: 'Booking', component: BookingComponent
            },
            { 
                path: 'booking/addbooking', component: AddBookingComponent
            }, 
             
            {
                path:'booking/updatebooking', component:UpdateBookingComponent
            },
            {
                path: 'Manage-Customer', component: ManageCustomerComponent
            },
            {
                path: 'Design', component: DesignComponent
            }
        ]
    },

    {
        path: 'customer', component: LayoutComponent, children: [
            
            {
                path: 'art-piece', component: ArtpieceComponent
            },
            {
                path: 'bookings', component: BookingComponent
            },
            {
                path: 'layout', component: LayoutComponent
            },
            {
                path: 'login', component: LoginComponent
            },
            {
                path: 'register', component: RegisterComponent
            }
        ]
    }

]

