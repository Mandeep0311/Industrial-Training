import { Component } from '@angular/core';

@Component({
  selector: 'app-update-design',
  imports: [],
  templateUrl: './update-design.component.html',
  styleUrl: './update-design.component.css'
})
export class UpdateDesignComponent {

}
