import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageDesignComponent } from './manage-design.component';

describe('ManageDesignComponent', () => {
  let component: ManageDesignComponent;
  let fixture: ComponentFixture<ManageDesignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageDesignComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageDesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
