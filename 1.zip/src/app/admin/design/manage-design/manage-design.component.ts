import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-design',
  imports: [],
  templateUrl: './manage-design.component.html',
  styleUrl: './manage-design.component.css'
})
export class ManageDesignComponent {

}
