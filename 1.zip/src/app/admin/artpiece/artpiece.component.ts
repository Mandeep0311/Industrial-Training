import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ArtpieceService } from '../../shared/Artpiece/artpiece.service';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-artpiece',
  imports: [],
  templateUrl: './artpiece.component.html',
  styleUrl: './artpiece.component.css'
})
export class ArtpieceComponent implements OnInit {

  

ngOnInit(): void {
  this.allArtpiece()
}
constructor(
  private ArtpieceServices: ArtpieceService,
  private router: Router,
  private toastr: ToastrService,
  private spinner: NgxSpinnerService
) {

}
categories: any[] = []

  allArtpiece() {
    this.spinner.show()
    this.ArtpieceServices.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.allArtpiece = data;
      console.log(this.categories);

      this.toastr.success("Success", 'ArtPiece Loaded')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all categories", err);
      });
  }




}
