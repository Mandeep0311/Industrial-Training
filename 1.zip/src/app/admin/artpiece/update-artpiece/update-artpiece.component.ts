import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ArtpieceService } from '../../../shared/Artpiece/artpiece.service';
import { Artpiece } from '../../../model/Artpiece/artpiece.model';

@Component({
  selector: 'app-update-artpiece',
  imports: [FormsModule],
  templateUrl: './update-artpiece.component.html',
  styleUrl: './update-artpiece.component.css'
})
export class UpdateArtpieceComponent {

  // id: any;

  // constructor(private activateRoute: ActivatedRoute,
  //   private spinner: NgxSpinnerService,
  //   private toastr : ToastrService,
  //   private artpieceService: ArtpieceService,
  //   private router: Router
  // ) {}
  
  //   ngOnInit(): void {
  //     this.id =this.activateRoute.snapshot.paramMap.get('id')
  //     this.getSingle()
  //   }
  //   ArtpieceObj: Artpiece={}

  //   getSingle() {
  //     this.spinner.show()
  //     this.artpieceService.getSingle(this.id).subscribe((res:any) =>{
  //       this.ArtpieceObj.name = res.name
  //       this.ArtpieceObj.imgUrl= res.ImgUrl
  //       this.spinner.hide()
  //     },
  //   err=> {
  //     this.spinner.hide()
  //     console.log(err,'Error in get single Artpiece');
  //     this.toastr.error('something went wrong', 'Error')
  //   })
  //   }
  //   submit() {
  //     this.spinner.show()
  //     this.artpieceService.updateData(this.id, this.ArtpieceObj).then (() => {
  //       this.spinner.hide()
  //       this.toastr.success("sucess", 'Artpiece Updated')
  //       this.router.navigateByUrl("/admin/Artpiece/manageArtpiece")
  //     },
  //     (err: any)=> {
  //       this.spinner.hide()
  //       console.log(err, 'Error in update Artpiece');
  //       this.toastr.error("something went wrong", 'Error')
  //     }
  //   )
  //   }
  }


