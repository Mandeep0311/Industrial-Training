import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Artpiece } from '../../../model/Artpiece/artpiece.model';
import { ArtpieceService } from '../../../shared/Artpiece/artpiece.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { CloudinaryService } from '../../../shared/cloudinary/cloudinary.service';

@Component({
  selector: 'app-add-artpiece',
  imports: [FormsModule],
  templateUrl: './add-artpiece.component.html',
  styleUrl: './add-artpiece.component.css'
})
export class AddArtpieceComponent {

  ArtpieceObj: Artpiece={}

  constructor(
    private ArtpieceService: ArtpieceService,
    private router: Router,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private cloudinaryService: CloudinaryService
  ) { }


  selectedFile: File | null = null;

  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }


  submit() {
    
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.ArtpieceObj.imgUrl = uploadedRes.secure_url
        this.ArtpieceService.add(this.ArtpieceObj).then((res: any) => {
          this.spinner.hide()
          this.toastr.success("Artpiece Added Successfully", 'Success')
          this.router.navigateByUrl("/admin/Artpiece/manageArtpiece")
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in add category');
            this.toastr.error("Something Went Wrong", 'Error')
          }
        )
      }, (err: any) => {
        this.spinner.hide()
        console.log(err, 'Error in upload image');
        this.toastr.error("Something Went Wrong to add Artpiece", 'Error')
      }
      )
    }
    else {
      this.spinner.hide()
      this.toastr.error("No file selected", "Error");
    }

  }

}
