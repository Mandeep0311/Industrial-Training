import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-post',
  imports: [],
  templateUrl: './manage-post.component.html',
  styleUrl: './manage-post.component.css'
})
export class ManagePostComponent {

}
