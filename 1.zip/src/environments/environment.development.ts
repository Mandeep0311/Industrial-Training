export const environment = {
    
    production:false,
        firebase: {
         apiKey: "AIzaSyCD3b-2cQXMJBzpDWvNzVFC2zhYW19ms0E",
        authDomain: "nature-nest-fbd6a.firebaseapp.com",
         projectId: "nature-nest-fbd6a",
        storageBucket: "nature-nest-fbd6a.firebasestorage.app",
        messagingSenderId: "503152142370",
        appId: "1:503152142370:web:9636bbccc2ab01e650827b",
        measurementId: "G-LWQT6TB0KF"
        }
};
