import { Routes } from '@angular/router';
import { LayoutComponent } from './admin/layout/layout.component';
import { CustomerComponent } from './customer/customer.component';
import { SellerComponent } from './seller/seller.component';
import { RegisterComponent } from './customer/register/register.component';
import { ProductComponent } from './custumer/product/product.component';
import { HomeComponent } from './admin/home/home.component';
import { LoginComponent } from './admin/login/login.component';

export const routes: Routes = [

    {
        path:'', redirectTo:'/admin/home', pathMatch:'full'
    },
    {path:'admin', component:LayoutComponent, children:[
        {path:'home', component:HomeComponent}]
    },
    {
        path:'custumer', component:CustomerComponent
    },
    {
        path:'seller', component:SellerComponent
    },
    {
        path:'register', component:RegisterComponent
    },
    {
        path:'product', component:ProductComponent
    },
    {
        path:'home', component:HomeComponent
    },
    {
        path:'login', component:LoginComponent
    
    }


];
