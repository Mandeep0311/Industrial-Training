import { Component } from '@angular/core';

@Component({
  selector: 'app-addproduct',
  imports: [],
  templateUrl: './addproduct.component.html',
  styleUrl: './addproduct.component.css'
})
export class AddproductComponent {

}
