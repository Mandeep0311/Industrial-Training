import { Component } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { BookingService } from '../../shared/booking.service';
import { Booking } from '../../models/booking.model';


@Component({
  selector: 'app-booking',
  imports: [FormsModule],
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent {

  title: 'Booking' = 'Booking';
  bookingObj: Booking = {} 

  constructor(private bookingServices: BookingService){}

  addBooking() {
    this.bookingServices.addBooking(this.bookingObj);
  }
}