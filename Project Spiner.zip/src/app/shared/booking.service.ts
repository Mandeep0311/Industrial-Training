import { Injectable } from '@angular/core';
import { Booking } from '../models/booking.model';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/compat/firestore';
import { ngxspinnerServices } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { map } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class BookingService {

  dbpath: string ="/booking";
  bookingRef: AngularFirestoreCollection<Booking>

  constructor(
    private db: AngularFirestore,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private router: Router) {
    this.bookingRef = db.collection(this.dbPath)
  }

  addBooking(data:any){
    this.spinner.show()
    this.bookingRef.add({...data}).then(
      ()=>{
        this.spinner.hide()
        this.toastr.success('Booking Created Successfully');
        this.router.navigateByUrl('/admin/dashboard');
    },
  (err)=>{
    this.spinner.hide();
    this.toastr.error("Something Went wrong");
    console.log(err)
  })
  }
}
