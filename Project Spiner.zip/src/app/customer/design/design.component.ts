import { Component } from '@angular/core';

@Component({
  selector: 'app-design',
  imports: [],
  templateUrl: './design.component.html',
  styleUrl: './design.component.css'
})
export class DesignComponent {

}
