export class Users {
    id?: String;
    name?: String;
    email?: String;
    contact?: String;
    address?: String;
    uid?: String;
    createdAt?: String;
    status?: String;
}
