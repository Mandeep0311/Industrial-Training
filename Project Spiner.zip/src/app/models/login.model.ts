export class Login {
    id?:String;
    userId?:String;
    token?:String;
    loginAt?:String;
    logOutAt?:String;
    status?:String;
    createdAt?:String;
}
