import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-artpiece',
  imports: [],
  templateUrl: './artpiece.component.html',
  styleUrl: './artpiece.component.css'
})
export class ArtpieceComponent {

}
