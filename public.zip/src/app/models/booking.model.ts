export class Booking {
    id?: String;
    userId?: String;
    userName?: String;
    useremail?: String;
    artPieceName?: String;
    designName?: String;
    designId?: String;
    size?: String;
    cost?: String;
    specification?: String;
    revertMessage?: String;
    status?: String;
    createdAt?: String;
    expectedReturnDate?: String;
    review?: String;
    finalImage?: String;

}
