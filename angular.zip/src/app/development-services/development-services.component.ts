import { Component } from '@angular/core';

@Component({
  selector: 'app-development-services',
  imports: [],
  templateUrl: './development-services.component.html',
  styleUrl: './development-services.component.css'
})
export class DevelopmentServicesComponent {

}
