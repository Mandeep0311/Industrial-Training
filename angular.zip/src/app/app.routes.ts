import { Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CatogoryComponent } from './catogory/catogory.component';
import { ContactComponent } from './contact/contact.component';
import { DevelopmentServicesComponent } from './development-services/development-services.component';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { ServicesComponent } from './services/services.component';
import { SubCatogoryComponent } from './sub-catogory/sub-catogory.component';
import { TrainingServicesComponent } from './training-services/training-services.component';

export const routes: Routes = [
  {path:'home',component:HomeComponent},
    {path: 'about', component:AboutComponent,
        children:[
            {path: 'contact', component:ContactComponent},
        ]
    },
    {path: 'Services', component:ServicesComponent,
        children:[
            {path: 'development-services', component:DevelopmentServicesComponent},
            {path: 'traning-services', component:TrainingServicesComponent},
        ]
    },
    {path: 'product', component: ProductComponent,
        children:[
            {path: 'catogory', component:CatogoryComponent},
            {path: 'sub-catogory', component:SubCatogoryComponent},
        ]
    },

    {path:'about', component:AboutComponent},
    {path:'contact', component:ContactComponent},
    {path:'services',component:ServicesComponent},
    {path:'development-services',component:DevelopmentServicesComponent},
    {path:'training-services',component:TrainingServicesComponent},
    {path:'product',component:ProductComponent},
    {path:'catogory',component:CatogoryComponent},
    {path:'subcatogory',component:SubCatogoryComponent},


];
