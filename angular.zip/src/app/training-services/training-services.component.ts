import { Component } from '@angular/core';

@Component({
  selector: 'app-training-services',
  imports: [],
  templateUrl: './training-services.component.html',
  styleUrl: './training-services.component.css'
})
export class TrainingServicesComponent {

}
