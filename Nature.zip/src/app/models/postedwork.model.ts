export class Postedwork {
    id?: String;
    userName?: String;
    review?: String;
    finalProductImageUrl?: String;
    cost?: String;
    createdAt?: String;
    status?: String;


}
