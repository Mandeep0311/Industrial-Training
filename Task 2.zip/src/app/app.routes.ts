import { Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { StudentComponent } from './student/student.component';
import { TeacherComponent } from './teacher/teacher.component';
import { LoginComponent } from './teacher/login/login.component';
import { REgisterComponent } from './teacher/register/register.component';
import { ViewProfileComponent } from './teacher/view-profile/view-profile.component';
import { StudentProfileComponent } from './student/student-profile/student-profile.component';


export const routes: Routes = [

    {path :'admin', component:AdminComponent, children:
        [   {path : 'teacher/login', component :LoginComponent},
            {path : 'teacher/register', component :REgisterComponent},
            {path : 'teacher/view-profile', component:ViewProfileComponent},
            {path : 'student/student-profile', component:StudentProfileComponent}
        ]
    },
    {path :'student', component:StudentComponent, children:
        [
            {path:'student-profile', component:StudentProfileComponent},
            {path : 'teacher/login', component :LoginComponent},
            {path : 'teacher/register', component :REgisterComponent},
            {path : 'teacher/view-profile', component:ViewProfileComponent}

        ]
    },

    {path :'teacher', component:TeacherComponent, children:
        [
            {path:'student-profile', component:StudentProfileComponent},
            {path : 'login', component :LoginComponent},
            {path : 'register', component :REgisterComponent},
            {path : 'view-profile', component:ViewProfileComponent}
    ]},

];
