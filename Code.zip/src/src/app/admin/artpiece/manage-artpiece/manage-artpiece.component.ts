import { Component, OnInit } from '@angular/core';
import { ArtpieceService } from '../../../shared/Artpiece/artpiece.service';
import { Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import swal from 'sweetalert2';
import { DatePipe } from '@angular/common';




@Component({
  selector: 'app-manage-artpiece',
  imports: [],
  templateUrl: './manage-artpiece.component.html',
  styleUrl: './manage-artpiece.component.css'
})
export class ManageArtpieceComponent  {

  // ngOnInit(): void {
  //   this.allArtpiece()
  // }

  // constructor(
  //   private artpieceService: ArtpieceService,
  //   private router: Router,
  //   private toastr: ToastrService,
  //   private spinner: NgxSpinnerService
  // ) {

  // }



  // categories: any[] = []

  // allArtpiece() {
  //   this.spinner.show()
  //   this.artpieceService.getAll().subscribe((data: any) => {
  //     this.spinner.hide()
  //     this.artpiece = data;
  //     console.log(this.artpiece);

  //     this.toastr.success("Success", 'Categories Loaded')
  //   },
  //     (err: any) => {
  //       this.spinner.hide()
  //       this.toastr.error('Error', err)
  //       console.log("error is get all Artpieces", err);
  //     });
  // }





  // deleteCat(id: any) {
  //   swal.fire({
  //     title: "Are you sure?",
  //     text: "You won't be able to revert this!",
  //     icon: "warning",
  //     showCancelButton: true,
  //     confirmButtonColor: "#3085d6",
  //     cancelButtonColor: "#d33",
  //     confirmButtonText: "Yes, delete it!"
  //   }).then((result) => {
  //     if (result.isConfirmed) {
  //       this.artpieceService.deleteData(id).then(() => {
  //         swal.fire({
  //           title: "Deleted!",
  //           text: "Your file has been deleted.",
  //           icon: "success"
  //         });

  //       },
  //         (err: any) => {
  //           console.log(err);
  //           this.toastr.error(err)

  //         }
  //       )
  //     }
  //   });
  // }

}

