import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddArtpieceComponent } from './add-artpiece.component';

describe('AddArtpieceComponent', () => {
  let component: AddArtpieceComponent;
  let fixture: ComponentFixture<AddArtpieceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddArtpieceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddArtpieceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
