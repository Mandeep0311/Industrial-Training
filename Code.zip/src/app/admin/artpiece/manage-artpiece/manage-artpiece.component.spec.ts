import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageArtpieceComponent } from './manage-artpiece.component';

describe('ManageArtpieceComponent', () => {
  let component: ManageArtpieceComponent;
  let fixture: ComponentFixture<ManageArtpieceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageArtpieceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageArtpieceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
