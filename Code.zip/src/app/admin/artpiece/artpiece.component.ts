import { Component } from '@angular/core';


@Component({
  selector: 'app-artpiece',
  imports: [],
  templateUrl: './artpiece.component.html',
  styleUrl: './artpiece.component.css'
})
export class ArtpieceComponent {

}
