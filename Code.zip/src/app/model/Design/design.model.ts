export class Design {
    id?: string;
    image?: string;
    name?: string;
    artpieceId?: string;
    discription?: string;
    artPieceName?: string;
    size?: string;
    status?: boolean;
    createdAt?: number;
}
