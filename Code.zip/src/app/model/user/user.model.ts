export class User {
    
    id?: string;
    name?: string;
    contact?: number;
    email?: string;
    password?: string;
    address?: string;
    userType?: number;
    uid?: string;
    status?: boolean;
    createdAt?: number;
}
