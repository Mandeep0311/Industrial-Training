export class Artpiece {

    id?: string;
    name?: string;
    discription?: string;
    imgUrl?: string;
    status?: boolean;
    createdAt?: number;
}
