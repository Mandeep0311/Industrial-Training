import { Component } from '@angular/core';

@Component({
  selector: 'app-add-booking',
  imports: [],
  templateUrl: './add-booking.component.html',
  styleUrl: './add-booking.component.css'
})
export class AddBookingComponent {

}
