import { Component } from '@angular/core';

@Component({
  selector: 'app-update-booking',
  imports: [],
  templateUrl: './update-booking.component.html',
  styleUrl: './update-booking.component.css'
})
export class UpdateBookingComponent {

}
