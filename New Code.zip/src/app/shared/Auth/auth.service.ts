import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() {}

    setData (res: any) {
    sessionStorage.setItem('Logged in', 'true')
    sessionStorage.setItem("email", res.email)
    sessionStorage.setItem("name", res.name)
    sessionStorage.setItem("uid", res.uid)
    sessionStorage.setItem("userType", res.userType)
   }
    getUid() {
    return sessionStorage.getItem('uid')
  }


  clear() {
    sessionStorage.clear()
  }
}
