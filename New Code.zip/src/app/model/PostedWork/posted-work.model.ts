export class PostedWork {
}
