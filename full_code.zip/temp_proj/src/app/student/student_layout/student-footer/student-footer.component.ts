import { Component } from '@angular/core';

@Component({
  selector: 'app-student-footer',
  imports: [],
  templateUrl: './student-footer.component.html',
  styleUrl: './student-footer.component.css'
})
export class StudentFooterComponent {

}
