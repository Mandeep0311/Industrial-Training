import { Injectable } from '@angular/core';
import { Firestore, collection, addDoc, getDocs, query, where } from '@angular/fire/firestore';
import { User } from '../../model/user.model';

@Injectable({
  providedIn: 'root'
})

export class UserService {

  constructor(private firestore: Firestore) { }

  setData(res: { token: string }) {
    sessionStorage.setItem('token', res.token);
  }
  
  getToken() {
    return sessionStorage.getItem('token');
  }

  async addUser(collectionName: string, data: any) {
    const userCollection = collection(this.firestore, collectionName);
    return await addDoc(userCollection, data);
  }

  async getUser(collectionName: string, email: string): Promise<User | null> {
    const userCollection = collection(this.firestore, collectionName);
    const q = query(userCollection, where('email', '==', email));
    const userFound = await getDocs(q);
  
    if (userFound.empty) {
      return null;
    } else {
      const userDoc = userFound.docs[0];
      return {
        id: userDoc.id,
        ...userDoc.data()
      } as User;
    }
  }
  
  async loginUser(collectionName: string, data: any) {
    const loginCollection = collection(this.firestore, collectionName);
    return await addDoc(loginCollection, data);
  }

  clear() {
    sessionStorage.clear();
  }
}
