import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';
import { UserService } from '../shared/user/user.service';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  title: 'Register' = 'Register'


  registerForm = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    contact: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  })

  constructor(private router: Router, private authService: AuthService, private userService: UserService) { }

  onSubmit() {
    alert(this.registerForm.value.firstName)
    if (
      this.registerForm.value.email == 'student@gmail.com' &&
      this.registerForm.value.password == '123'
    ) {
      this.authService.setData(this.registerForm.value)
      this.router.navigateByUrl('/login');
    } else {
      alert('Invalid email or password');
    }
  }
  async saveData() {
    const data = {
      firstName: this.registerForm.value.firstName,
      lastName: this.registerForm.value.lastName,
      contact: this.registerForm.value.contact,
      email: this.registerForm.value.email,
      password: this.registerForm.value.password,
      status: true,
      createdAt: Date.now()
    };
  
    try {
      const userExist = await this.userService.getUser('users', data.email!);
      if (!userExist) {
        await this.userService.addUser('users', data);
        alert("User registered successfully.");
        this.authService.setData(data);
        this.router.navigateByUrl('/login');
      } else {
        alert("User already registered");
      }
    } catch (error) {
      console.error("Error during registration:", error);
      alert("An error occurred: " + error);
    }
  }
  
}