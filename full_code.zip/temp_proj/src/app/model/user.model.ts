export class User {
    id?:String;
    firstName?:String;
    lastName?:String;
    contact?:String;
    email?:String;
    password?:String;
    status?:String;
    createdAt?:String;
    updatedAt?:String;
}