export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyBBhklRf02PjHCSHjQgOCQDB5SMWJY1pd8",
        authDomain: "mypro-e7e84.firebaseapp.com",
        projectId: "mypro-e7e84",
        storageBucket: "mypro-e7e84.firebasestorage.app",
        messagingSenderId: "549336752833",
        appId: "1:549336752833:web:90b2dfa97bcc76fbc36a40",
        measurementId: "G-M42F5D5DKL"
    }
};
