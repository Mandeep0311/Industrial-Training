import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-catogory',
  imports: [],
  templateUrl: './sub-catogory.component.html',
  styleUrl: './sub-catogory.component.css'
})
export class SubCatogoryComponent {

}
