import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubCatogoryComponent } from './sub-catogory.component';

describe('SubCatogoryComponent', () => {
  let component: SubCatogoryComponent;
  let fixture: ComponentFixture<SubCatogoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubCatogoryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubCatogoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
