import { Component } from '@angular/core';

@Component({
  selector: 'app-catogory',
  imports: [],
  templateUrl: './catogory.component.html',
  styleUrl: './catogory.component.css'
})
export class CatogoryComponent {

}
