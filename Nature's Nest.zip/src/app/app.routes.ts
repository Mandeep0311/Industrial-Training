import { Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CarpenterComponent } from './carpenter/carpenter.component';
import { SellerComponent } from './seller/seller.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { ProjectComponent } from './project/project.component';
import { FeatureComponent } from './feature/feature.component';
import { ContactComponent } from './contact/contact.component';


export const routes: Routes = [

      
    {path: '', redirectTo: '/about',pathMatch: 'full' },
    {path:'admin', component:AdminComponent},
    {path:'carpenter', component:CarpenterComponent},
    {path:'seller', component:SellerComponent},
    {path:'about', component:AboutComponent},
    {path:'services', component:ServicesComponent},
    {path:'project', component:ProjectComponent},
    {path:'home', component:ProjectComponent},
    {path:'feature', component:FeatureComponent},
    {path:'contact', component:ContactComponent},
];
