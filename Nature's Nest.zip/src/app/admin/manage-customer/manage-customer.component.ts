import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-customer',
  imports: [],
  templateUrl: './manage-customer.component.html',
  styleUrl: './manage-customer.component.css'
})
export class ManageCustomerComponent {

}
