import { Component } from '@angular/core';

@Component({
  selector: 'app-art-pieces',
  imports: [],
  templateUrl: './art-pieces.component.html',
  styleUrl: './art-pieces.component.css'
})
export class AdminArtPiecesComponent {

}
