import { Postedwork } from './postedwork.model';

describe('Postedwork', () => {
  it('should create an instance', () => {
    expect(new Postedwork()).toBeTruthy();
  });
});
