import { Component } from '@angular/core';

@Component({
  selector: 'app-carpenter',
  imports: [],
  templateUrl: './carpenter.component.html',
  styleUrl: './carpenter.component.css'
})
export class CarpenterComponent {

}
