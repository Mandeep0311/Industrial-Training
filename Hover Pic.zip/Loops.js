const employees = [ 
    { id: 1, name: "Amit", salary: 50000, department: "IT", status: "active" }, 
    { id: 2, name: "Neha", salary: 60000, department: "HR", status: "inactive" },
    { id: 3, name: "Raj", salary: 55000, department: "IT", status: "active" }, 
    { id: 4, name: "Priya", salary: 70000, department: "Finance", status: "inactive" },
    { id: 5, name: "Vikram", salary: 65000, department: "HR", status: "active" }
    ]
    console.log(employees);

    
    const activeemployees = employees.filter(employees => employees.status == "active")
        console.log(activeemployees); 
    
    const employeesname = employees.map
    
        (employees => employees.name);
    
        console.log(employeesname); 
    
    const employeesdetails = employees.map

        (employees => employees.name, employees.department);
    
        console.log(employeesdetails);

          
    const highsalaryemployee = (employees.filter(employees=>
        employees.salary > 60000));

        console.log(highsalaryemployee);
    

    