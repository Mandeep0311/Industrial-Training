import { Component } from '@angular/core';

@Component({
  selector: 'app-seller',
  imports: [],
  templateUrl: './seller.component.html',
  styleUrl: './seller.component.css'
})
export class SellerComponent {

}
