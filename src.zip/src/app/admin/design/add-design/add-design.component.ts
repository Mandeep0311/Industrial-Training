import { Component } from '@angular/core';

@Component({
  selector: 'app-add-design',
  imports: [],
  templateUrl: './add-design.component.html',
  styleUrl: './add-design.component.css'
})
export class AddDesignComponent {

}
