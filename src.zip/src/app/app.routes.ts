import { Routes } from '@angular/router';

import { CarpenterComponent } from './carpenter/carpenter.component';
import { SellerComponent } from './seller/seller.component';
import { AboutComponent } from './admin/about/about.component';
import { ServicesComponent } from './services/services.component';
import { ProjectComponent } from './project/project.component';
import { FeatureComponent } from './feature/feature.component';
import { ContactComponent } from './admin/contact/contact.component';
import { HomeComponent } from './home/home.component';
import { LayoutComponent } from './admin/layout/layout.component';
import { AdminHomeComponent } from './admin/home/home.component';


export const routes: Routes = [

      
    {
        path: '', redirectTo: 'admin/home',pathMatch: 'full'

     },
     { path:'Home', component:HomeComponent},

    {path:'admin', component:LayoutComponent, children:[
        {path:'home', component:AdminHomeComponent},
    ]},
    {path:'carpenter', component:CarpenterComponent},
    {path:'seller', component:SellerComponent},
    {path:'about', component:AboutComponent},
    {path:'services', component:ServicesComponent},
    {path:'project', component:ProjectComponent},
    {path:'feature', component:FeatureComponent},
    {path:'contact', component:ContactComponent},
    
];
