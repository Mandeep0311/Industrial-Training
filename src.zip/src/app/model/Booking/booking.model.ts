export class Booking {

    id?: string;
    UserId?: string;
    userName?: string;
    useremail?: string;
    artPieceName?: string;
    designName?: string;
    designId?: string;
    size?: string;
    cost?: string;
    specification?: string;
    revertMessage?: string;
    status?: boolean;
    createdAt?: number;
    expectedReturnDate?: string;
    review?: string;
    finalImage?: string;
}

